package cs455_martina_final;

public class NullUser extends User{
	@Override
    public boolean isNil() {
        return true;
    }
}
