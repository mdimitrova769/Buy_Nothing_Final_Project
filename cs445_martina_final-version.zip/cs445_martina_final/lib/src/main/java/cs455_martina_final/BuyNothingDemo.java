package cs455_martina_final;


import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/")
public class BuyNothingDemo extends Application{
	
}
